package com.kia.blagogramapp.utils

import java.text.SimpleDateFormat
import java.util.*

object TimeUtils {

    fun formatTimestamp(raw: String): String {
        // Исходный формат: "2025-11-19 10:00:00"
        val inputFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
        val date = inputFormat.parse(raw) ?: return ""

        val now = Calendar.getInstance()
        val msg = Calendar.getInstance()
        msg.time = date

        // СЕГОДНЯ → HH:mm
        val isToday = now.get(Calendar.YEAR) == msg.get(Calendar.YEAR) &&
                now.get(Calendar.DAY_OF_YEAR) == msg.get(Calendar.DAY_OF_YEAR)
        if (isToday) {
            return SimpleDateFormat("HH:mm", Locale.getDefault()).format(date)
        }

        // ВЧЕРА
        now.add(Calendar.DAY_OF_YEAR, -1)
        val isYesterday = now.get(Calendar.YEAR) == msg.get(Calendar.YEAR) &&
                now.get(Calendar.DAY_OF_YEAR) == msg.get(Calendar.DAY_OF_YEAR)
        if (isYesterday) return "Вчера"

        // Название дня недели (если в пределах 7 дней)
        val diff = (Calendar.getInstance().timeInMillis - msg.timeInMillis) / (1000 * 60 * 60 * 24)
        if (diff in 2..6) {
            return SimpleDateFormat("EEE", Locale("ru")).format(date).replace(".", "")
        }

        // В этом году → 14 нояб
        if (now.get(Calendar.YEAR) == msg.get(Calendar.YEAR)) {
            return SimpleDateFormat("d MMM", Locale("ru")).format(date)
        }

        // Старше → 14.11.2023
        return SimpleDateFormat("dd.MM.yyyy", Locale.getDefault()).format(date)
    }
}
