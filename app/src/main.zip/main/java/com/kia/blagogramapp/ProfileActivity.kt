package com.kia.blagogramapp

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import coil.load
import com.google.android.material.imageview.ShapeableImageView
import androidx.core.content.edit

class ProfileActivity : AppCompatActivity() {

    private val PICK_AVATAR = 1001

    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)

        val cover = findViewById<ImageView>(R.id.profileCover)
        val usernameTv = findViewById<TextView>(R.id.profileUsername)
        val handleTv = findViewById<TextView>(R.id.profileHandle)
        val inputName = findViewById<EditText>(R.id.inputName)
        val inputStatus = findViewById<EditText>(R.id.inputStatus)
        val btnSave = findViewById<Button>(R.id.btnSaveProfile)
        val btnExit = findViewById<ImageView>(R.id.exit_profile)
        val avatarEdit = findViewById<ImageView>(R.id.avatarEdit)

        // Заглушки / данные из SharedPreferences
        val prefs = getSharedPreferences("app", MODE_PRIVATE)
        val savedName = prefs.getString("name", "") ?: ""
        val savedStatus = prefs.getString("status", "") ?: ""
        val id = "@" + getSharedPreferences("app", MODE_PRIVATE).getString("login", "Мой ид") // ИД пользователя
        val username = getSharedPreferences("app", MODE_PRIVATE).getString("display_name", "Мое имя") // Имя пользователя
        val coverUrl = prefs.getString("cover_url", "") ?: ""

        usernameTv.text = username
        handleTv.text = id
        inputName.setText(savedName)
        inputStatus.setText(savedStatus)

        // Загружаем обложку (если пусто — используем твой локальный загруженный файл)
        val coverToLoad = coverUrl.ifEmpty { "file:///mnt/data/bbe5438b-b507-4196-a66e-a8b31da1390c.png" }
        cover.load(coverToLoad) {
            crossfade(true)
            placeholder(R.drawable.ic_user_placeholder)
        }

        val avatarFile = prefs.getString("avatar", "")

        val avatar = findViewById<ShapeableImageView>(R.id.profileAvatar)

        // Аватар
        avatar.load("https://blagogram.u-host.in/avatars/$avatarFile") {
            crossfade(true)
            placeholder(R.drawable.ic_user_placeholder)
            error(R.drawable.ic_user_placeholder)
        }


        avatarEdit.setOnClickListener {
            // простой пикер для выбора картинки из галереи
            val i = Intent(Intent.ACTION_PICK)
            i.type = "image/*"
            startActivityForResult(i, PICK_AVATAR)
        }

        btnSave.setOnClickListener {
            prefs.edit {
                putString("name", inputName.text.toString())
                putString("status", inputStatus.text.toString())
            }
            btnSave.text = "Сохранено"
            btnSave.postDelayed({ btnSave.text = "СОХРАНИТЬ" }, 1200)
        }

        btnExit.setOnClickListener {
            finish()
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 1001 && resultCode == Activity.RESULT_OK) {
            val uri = data?.data ?: return
            // сохраняем ссылку в prefs и обновляем avatar
            val prefs = getSharedPreferences("app", MODE_PRIVATE)
            prefs.edit { putString("avatar_url", uri.toString()) }

            val avatar = findViewById<ShapeableImageView>(R.id.profileAvatar)
            avatar.load(uri.toString()) { crossfade(true) }
        }
    }
}
