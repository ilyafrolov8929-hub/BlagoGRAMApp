package com.kia.blagogramapp.api

import com.kia.blagogramapp.BlagoApi
import com.kia.blagogramapp.model.Chat
import com.kia.blagogramapp.model.Message

class ApiRepository(private val api: BlagoApi) {

    // ---------------------------
    // LOGIN
    // ---------------------------
    suspend fun login(login: String, password: String): Map<String, Any> {

        val resp = api.call(
            ApiRequest(
                action = "auth.login",
                login = login,
                password = password
            )
        )

        val body = resp.body() ?: throw Exception("Empty response")

        if (body["ok"] != true)
            throw Exception(body["error"].toString())

        return body["result"] as Map<String, Any>
    }

    // ---------------------------
    // CHATS LIST
    // ---------------------------
    suspend fun getChats(token: String): List<Chat> {

        val resp = api.call(
            ApiRequest(
                action = "chats.get",
                token = token
            )
        )

        val body = resp.body() ?: throw Exception("Empty response")

        if (body["ok"] != true)
            throw Exception(body["error"].toString())

        val list = body["result"] as List<Map<String, Any>>

        return list.map {
            Chat(
                id = (it["chat_id"] as Number).toInt(),
                name = it["name"]?.toString(),
                avatar = it["avatar"]?.toString(),
                last_msg = it["last_message"]?.toString(),
                last_time = it["last_time"]?.toString(),
                unread = (it["unread"] as Number).toInt()
            )
        }
    }

    // ---------------------------
    // GET MESSAGES
    // ---------------------------
    suspend fun getMessages(token: String, chatId: Int): List<Message> {

        val resp = api.call(
            ApiRequest(
                action = "messages.get",
                token = token,
                chat_id = chatId
            )
        )

        val body = resp.body() ?: throw Exception("Empty response")

        if (body["ok"] != true)
            throw Exception(body["error"].toString())

        val list = body["result"] as List<Map<String, Any>>

        return list.map {
            Message(
                id = (it["id"] as Number).toInt(),
                chat_id = (it["chat_id"] as Number).toInt(),
                sender_id = (it["sender_id"] as Number).toInt(),
                content = it["content"].toString(),
                sent_at = it["sent_at"].toString(),
                is_read = (it["is_read"] as Number).toInt(),   // 🔥 ДОБАВЬ ЭТО
                avatar = it["avatar"].toString(),
                display_name = it["display_name"].toString()
            )

        }
    }

    // ---------------------------
    // SEND MESSAGE
    // ---------------------------
    suspend fun sendMessage(token: String, chatId: Int, text: String): Boolean {

        val resp = api.call(
            ApiRequest(
                action = "message.send",
                token = token,
                chat_id = chatId,
                text = text
            )
        )

        val body = resp.body() ?: throw Exception("Empty response")

        if (body["ok"] != true)
            throw Exception(body["error"].toString())

        return true
    }

    // ---------------------------
    // CREATE CHAT
    // ---------------------------
    suspend fun createChat(token: String, userId: Int): Int {

        val resp = api.call(
            ApiRequest(
                action = "chat.create",
                token = token,
                user_id = userId
            )
        )

        val body = resp.body() ?: throw Exception("Empty response")

        if (body["ok"] != true)
            throw Exception(body["error"].toString())

        val result = body["result"] as Map<String, Any>

        return (result["chat_id"] as Number).toInt()
    }
}
