package com.kia.blagogramapp

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class StartActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("app", MODE_PRIVATE)
        val savedToken = prefs.getString("token", "")

        if (!savedToken.isNullOrEmpty()) {
            startActivity(Intent(this, ChatsActivity::class.java))
            finish()
            return
        }

        setContentView(R.layout.activity_start)

        val btn = findViewById<Button>(R.id.btnStart)
        btn.setOnClickListener {
            startActivity(Intent(this, LoginActivity::class.java))
        }
    }
}
