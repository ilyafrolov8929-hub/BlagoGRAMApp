package com.kia.blagogramapp.api

import retrofit2.http.Field
import retrofit2.http.FormUrlEncoded
import retrofit2.http.POST

interface ApiService {

    @FormUrlEncoded
    @POST("index.php")
    suspend fun login(
        @Field("action") action: String = "auth.login",
        @Field("login") login: String,
        @Field("password") password: String
    ): LoginResponse


    @FormUrlEncoded
    @POST("index.php")
    suspend fun getChats(
        @Field("action") action: String = "chats.get",
        @Field("token") token: String
    ): ChatListResponse


    @FormUrlEncoded
    @POST("index.php")
    suspend fun getMessages(
        @Field("action") action: String = "messages.get",
        @Field("token") token: String,
        @Field("chat_id") chatId: Int
    ): MessageListResponse


    @FormUrlEncoded
    @POST("index.php")
    suspend fun sendMessage(
        @Field("action") action: String = "message.send",
        @Field("token") token: String,
        @Field("chat_id") chatId: Int,
        @Field("text") text: String
    ): SendMessageResponse


    @FormUrlEncoded
    @POST("index.php")
    suspend fun createChat(
        @Field("action") action: String = "chat.create",
        @Field("token") token: String,
        @Field("user_id") userId: Int
    ): CreateChatResponse

    @FormUrlEncoded
    @POST("get_chats.php")
    suspend fun getChats(
        @Field("user_id") userId: Int
    ): ChatsResponse

}
