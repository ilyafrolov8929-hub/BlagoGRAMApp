package com.kia.blagogramapp

import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.drawerlayout.widget.DrawerLayout
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.kia.blagogramapp.adapters.ChatsAdapter
import com.kia.blagogramapp.api.ApiClient
import com.kia.blagogramapp.api.ApiRepository
import com.kia.blagogramapp.model.Chat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import com.kia.blagogramapp.models.ChatItem
import com.kia.blagogramapp.network.RetrofitClient
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import coil.load
import com.google.android.material.navigation.NavigationView

private lateinit var drawer: DrawerLayout
private lateinit var navigationView: NavigationView



class ChatsActivity : AppCompatActivity() {

    var repo = ApiRepository(RetrofitClient.api)
    private lateinit var recycler: RecyclerView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_chats)

        val header = findViewById<NavigationView>(R.id.navigationView).getHeaderView(0)

        val headerAvatar = header.findViewById<ImageView>(R.id.navAvatar)
        val headerId   = header.findViewById<TextView>(R.id.navUsername)
        val headerName   = header.findViewById<TextView>(R.id.navUsername)

        // получаем данные
        val avatar = getSharedPreferences("app", MODE_PRIVATE).getString("avatar", "")
        val username = getSharedPreferences("app", MODE_PRIVATE).getString("display_name", "Мое имя") // Имя пользователя
        val iduser = getSharedPreferences("app", MODE_PRIVATE).getString("login", "Мой ид") // ИД пользователя

        // ставим имя
        headerId.text = username
        headerName.text = "@$iduser"

        // ставим фото
        headerAvatar.load("https://blagogram.u-host.in/avatars/$avatar") {
            crossfade(true)
            placeholder(R.drawable.ic_user_placeholder)
            error(R.drawable.ic_user_placeholder)
        }


        drawer = findViewById(R.id.drawerLayout)
        navigationView = findViewById(R.id.navigationView)

        findViewById<ImageView>(R.id.menuBtn).setOnClickListener {
            drawer.openDrawer(Gravity.LEFT)
        }

        navigationView.setNavigationItemSelectedListener { item ->
            when (item.itemId) {
                R.id.item_logout -> {
                    getSharedPreferences("app", MODE_PRIVATE).edit().clear().apply()
                    finish()
                }
                R.id.item_profile -> {
                    val i = Intent(this, ProfileActivity::class.java)
                    i.putExtra("avatar", avatar)   // ДОБАВЬ ЭТО
                    startActivity(Intent(this, ProfileActivity::class.java))
                    drawer.closeDrawers()
                    true
                }
            }
            drawer.closeDrawer(Gravity.LEFT)
            true
        }

        val api = ApiClient.retrofit.create(BlagoApi::class.java)
        repo = ApiRepository(api)

        recycler = findViewById(R.id.recyclerChats)
        recycler.layoutManager = LinearLayoutManager(this)

        val swipe = findViewById<SwipeRefreshLayout>(R.id.swipeChats)
        swipe.setOnRefreshListener {
            loadChats()
        }

        loadChats()
    }


    private fun loadChats() {
        val token = getSharedPreferences("app", MODE_PRIVATE)
            .getString("token", "") ?: ""

        CoroutineScope(Dispatchers.IO).launch {
            try {
                val chats: List<Chat> = repo.getChats(token)

                val items: List<ChatItem> = chats.map { c ->
                    ChatItem(
                        chat_id = c.id,
                        user_id = 0, // если нет user_id — ставим заглушку
                        name = c.name ?: "",
                        avatar = c.avatar,
                        last_message = c.last_msg,   // вот тут ИСПРАВЛЕНО
                        last_time = c.last_time,
                        unread = c.unread
                    )
                }

                runOnUiThread {
                    recycler.adapter = ChatsAdapter(items) { chat ->
                        val i = Intent(this@ChatsActivity, ChatActivity::class.java)
                        i.putExtra("chat_id", chat.chat_id)
                        i.putExtra("chat_name", chat.name)
                        i.putExtra("chat_avatar", chat.avatar)
                        i.putExtra("chat_last_message", chat.last_message)
                        i.putExtra("chat_last_time", chat.last_time)
                        startActivity(i)
                    }

                    val swipe = findViewById<SwipeRefreshLayout>(R.id.swipeChats)
                    swipe.isRefreshing = false
                }


            } catch (e: Exception) {
                runOnUiThread { e.printStackTrace() }
            }
        }
    }


}
