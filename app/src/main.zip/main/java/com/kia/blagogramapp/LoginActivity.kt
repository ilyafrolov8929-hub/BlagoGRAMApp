package com.kia.blagogramapp

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.kia.blagogramapp.api.ApiClient
import kotlinx.coroutines.launch
import androidx.core.content.edit

class LoginActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        val login = findViewById<EditText>(R.id.login)
        val password = findViewById<EditText>(R.id.password)
        val btn = findViewById<Button>(R.id.btnLogin)

        btn.setOnClickListener {
            val l = login.text.toString().trim()
            val p = password.text.toString().trim()

            if (l.isEmpty() || p.isEmpty()) {
                Toast.makeText(this, "Введите логин и пароль", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            lifecycleScope.launch {
                try {
                    val response = ApiClient.api.login(
                        login = l,
                        password = p
                    )

                    if (!response.ok) {
                        Toast.makeText(this@LoginActivity, response.error ?: "Ошибка", Toast.LENGTH_LONG).show()
                        return@launch
                    }

                    val result = response.result
                    if (result == null) {
                        Toast.makeText(this@LoginActivity, "Пустой ответ сервера", Toast.LENGTH_LONG).show()
                        return@launch
                    }

                    val token = result.token
                    val userId = result.user_id

                    if (token.isEmpty() || userId == null) {
                        Toast.makeText(this@LoginActivity, "Некорректный ответ сервера", Toast.LENGTH_LONG).show()
                        return@launch
                    }

                    // ✅ Сохраняем token и user_id
                    getSharedPreferences("app", MODE_PRIVATE).edit {
                        putString("token", token)
                        putInt("user_id", userId)
                        putString("avatar", result.avatar)   // ← твой параметр
                        putString("login", l)
                        putString("display_name", l)
                    }

                    startActivity(Intent(this@LoginActivity, ChatsActivity::class.java))
                    finish()

                } catch (e: Exception) {
                    Toast.makeText(this@LoginActivity, "Ошибка сети: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }
}
