package com.kia.blagogramapp

import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import coil.load
import com.google.android.material.imageview.ShapeableImageView
import com.kia.blagogramapp.adapters.MessagesAdapter
import com.kia.blagogramapp.api.ApiClient
import com.kia.blagogramapp.api.ApiRepository
import com.kia.blagogramapp.model.Message
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class ChatActivity : AppCompatActivity() {

    private lateinit var repo: ApiRepository
    private var chatId: Int = 0
    private lateinit var recycler: RecyclerView
    private lateinit var adapter: MessagesAdapter

    private fun setupKeyboardListener() {
        val rootView = findViewById<View>(android.R.id.content)

        rootView.viewTreeObserver.addOnGlobalLayoutListener {
            val heightDiff = rootView.rootView.height - rootView.height
            val isKeyboardOpen = heightDiff > 300

            if (isKeyboardOpen) {
                recycler.post {
                    recycler.smoothScrollToPosition(adapter.itemCount - 1)
                }
            }
        }
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_chat)
        setupKeyboardListener()


        val avatar = intent.getStringExtra("chat_avatar")
        val avatarView = findViewById<ShapeableImageView>(R.id.chatAvatar)

        avatarView.load("https://blagogram.u-host.in/avatars/$avatar") {
            crossfade(true)
            placeholder(R.drawable.ic_user_placeholder)
            error(R.drawable.ic_user_placeholder)
        }

        chatId = intent.getIntExtra("chat_id", 0)
        val chatName = intent.getStringExtra("chat_name") ?: "Чат"
        findViewById<TextView>(R.id.chatName).text = chatName
        if (chatId == 0) {
            finish()
            return
        }

        repo = ApiRepository(ApiClient.retrofit.create(BlagoApi::class.java))

        recycler = findViewById(R.id.messagesList)
        recycler.layoutManager = LinearLayoutManager(this)

        val myId = getSharedPreferences("app", MODE_PRIVATE).getInt("user_id", 0)

        adapter = MessagesAdapter(emptyList(), myId)
        recycler.adapter = adapter

        findViewById<ImageView>(R.id.backBtn).setOnClickListener {
            finish()
        }

        loadMessages()

        val input = findViewById<EditText>(R.id.messageInput)
        val btn = findViewById<ImageView>(R.id.sendBtn)

        btn.setOnClickListener {
            val text = input.text.toString()
            if (text.isNotBlank()) {
                sendMessage(text)
                input.text.clear()
            }
        }
    }

    private fun loadMessages() {
        val token = getSharedPreferences("app", MODE_PRIVATE).getString("token", "") ?: ""
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val messages: List<Message> = repo.getMessages(token, chatId)
                runOnUiThread {
                    adapter.update(messages)
                    recycler.scrollToPosition(messages.size - 1)
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    private fun sendMessage(text: String) {
        val token = getSharedPreferences("app", MODE_PRIVATE).getString("token", "") ?: ""
        CoroutineScope(Dispatchers.IO).launch {
            try {
                repo.sendMessage(token, chatId, text)
                loadMessages()
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }
}
