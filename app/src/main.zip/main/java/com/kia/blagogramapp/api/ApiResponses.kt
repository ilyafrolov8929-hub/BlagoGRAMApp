package com.kia.blagogramapp.api

import com.kia.blagogramapp.model.Chat

data class LoginResponse(
    val ok: Boolean,
    val result: LoginResult?,
    val error: String?
)

data class LoginResult(
    val user_id: Int,
    val username: String,
    val display_name: String,
    val avatar: String,
    val token: String
)

data class ChatsResponse(
    val status: Boolean,
    val chats: List<Chat>
)

data class ChatListResponse(
    val ok: Boolean,
    val result: List<ChatItem>?,
    val error: String?
)

data class ChatItem(
    val chat_id: Int,
    val user_id: Int,
    val name: String,
    val avatar: String,
    val last_message: String?,
    val last_time: String?,
    val unread: Int
)

data class MessageListResponse(
    val ok: Boolean,
    val result: List<MessageItem>?,
    val error: String?
)

data class MessageItem(
    val id: Int,
    val sender_id: Int,
    val content: String,
    val sent_at: String,
    val display_name: String,
    val avatar: String
)

data class SendMessageResponse(
    val ok: Boolean,
    val result: SendMessageResult?,
    val error: String?
)

data class SendMessageResult(
    val message_id: Int,
    val sent_at: String
)

data class CreateChatResponse(
    val ok: Boolean,
    val result: CreateChatResult?,
    val error: String?
)

data class CreateChatResult(
    val chat_id: Int
)


