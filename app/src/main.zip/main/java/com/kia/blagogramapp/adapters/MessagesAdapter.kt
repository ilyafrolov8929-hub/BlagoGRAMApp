package com.kia.blagogramapp.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.kia.blagogramapp.R
import com.kia.blagogramapp.model.Message

class MessagesAdapter(
    private var items: List<Message>,
    private val myId: Int
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    private val TYPE_LEFT = 1
    private val TYPE_RIGHT = 2

    override fun getItemViewType(position: Int): Int {
        return if (items[position].sender_id == myId) TYPE_RIGHT else TYPE_LEFT
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val layout = if (viewType == TYPE_RIGHT)
            R.layout.message_right
        else
            R.layout.message_left

        val v = LayoutInflater.from(parent.context).inflate(layout, parent, false)
        return MsgHolder(v)
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val h = holder as MsgHolder
        val msg = items[position]

        h.text.text = msg.content
        h.time.text = msg.sent_at.substring(11, 16) // "HH:MM"
    }

    override fun getItemCount() = items.size

    fun update(newItems: List<Message>) {
        items = newItems
        notifyDataSetChanged()
    }

    inner class MsgHolder(v: View) : RecyclerView.ViewHolder(v) {
        val text: TextView = v.findViewById(R.id.msgText)
        val time: TextView = v.findViewById(R.id.msgTime)
    }
}

